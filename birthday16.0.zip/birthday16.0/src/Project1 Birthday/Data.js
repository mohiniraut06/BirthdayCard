const data = [
  {
    id: 1,
    name: 'Shah Rukh Khan',
    age: 58,
    image:
      'https://static.ffx.io/images/$zoom_0.101%2C$multiply_2.1164%2C$ratio_1%2C$width_378%2C$x_0%2C$y_114/t_crop_custom/e_sharpen:25%2Cq_85%2Cf_auto/86223f5f9ce56304e84d7b39a665a6892724eec0',
  },
  {
    id: 2,
    name: 'Sidharth Malhotra ',
    age: 38,
    image:
      'https://timesofindia.indiatimes.com/thumb/msid-71203232,width-800,height-600,resizemode-4/71203232.jpg',
  },
  {
    id: 3,
    name: ' Varun Dhawan ',
    age: 36,
    image:
      'https://cdn.dnaindia.com/sites/default/files/styles/full/public/2019/06/14/836354-varundhawan-061519.jpg',
  },
  {
    id: 4,
    name: 'Sooraj Pancholi',
    age: 33,
    image:
      'https://www.hindustantimes.com/ht-img/img/2023/10/05/550x309/sooraj_1696484832082_1696484851786.jpg',
  },
  {
    id: 5,
    name: 'Ranbir Kapoor',
    age: 41,
    image:'https://images.mid-day.com/images/images/2023/mar/ranbir-tjmm_d.jpg',
  },
  {
      id: 6,
      name: 'Zayn Malik',
      age: 30,
      image:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMQNuaY1bsMjJILtWpjZIoLJeqIYqCuAlMpA&usqp=CAU',
    },
];

export default data